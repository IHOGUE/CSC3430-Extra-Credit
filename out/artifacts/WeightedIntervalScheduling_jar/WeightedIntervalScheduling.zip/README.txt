java -jar WeightedIntervalScheduling.jar c test.csv
command for command prompt

i want to test ubuntu's terminal
use these two arguments: c test.csv